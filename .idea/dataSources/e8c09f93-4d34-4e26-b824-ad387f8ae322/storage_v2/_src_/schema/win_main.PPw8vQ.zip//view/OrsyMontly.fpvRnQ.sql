create definer = root@`%` view OrsyMontly as
select `win_main`.`Customer`.`CustNo`                         AS `CustNo`,
       `win_main`.`Customer`.`Name`                           AS `Name`,
       `win_main`.`Customer`.`AssignedRepID`                  AS `AssignedRepID`,
       `win_main`.`Customer`.`Orsy`                           AS `Orsy`,
       `win_main`.`Customer`.`PreviousRollingTurnover`        AS `PreviousRollingTurnover`,
       `win_main`.`Customer`.`CurrentRollingTurnover`         AS `CurrentRollingTurnover`,
       month(`win_main`.`DW_PurchaseHistories`.`InvoiceDate`) AS `Month(``DW_PurchaseHistories``.``InvoiceDate``)`,
       year(`win_main`.`DW_PurchaseHistories`.`InvoiceDate`)  AS `Year(``DW_PurchaseHistories``.``InvoiceDate``)`,
       sum(`win_main`.`DW_PurchaseHistories`.`Amount`)        AS `Sum( ``DW_PurchaseHistories``.``Amount``)`
from (`win_main`.`Customer`
         left join `win_main`.`DW_PurchaseHistories`
                   on ((`win_main`.`DW_PurchaseHistories`.`CustomerID` = `win_main`.`Customer`.`ID`)))
where ((month(`win_main`.`DW_PurchaseHistories`.`InvoiceDate`) = month(curdate())) and
       (year(curdate()) = year(`win_main`.`DW_PurchaseHistories`.`InvoiceDate`)) and (`win_main`.`Customer`.`Orsy` = 1))
group by `win_main`.`Customer`.`CustNo`, year(`win_main`.`DW_PurchaseHistories`.`InvoiceDate`);

