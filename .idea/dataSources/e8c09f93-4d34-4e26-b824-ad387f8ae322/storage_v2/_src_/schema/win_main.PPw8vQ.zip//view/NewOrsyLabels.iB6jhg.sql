create definer = root@`%` view NewOrsyLabels as
select distinct `win_main`.`DW_PurchaseHistories`.`ProductNumber`      AS `ArtNo`,
                `win_main`.`DW_PurchaseHistories`.`ProductDescription` AS `Art_Description`,
                `win_main`.`Product_Dimension`.`Diameter`              AS `Diameter`,
                `win_main`.`Product_Dimension`.`Lenth`                 AS `Lenth`,
                `win_main`.`Product_Dimension`.`ImageMap`              AS `ImageMap`,
                `win_main`.`Customer`.`Name`                           AS `Name`,
                `win_main`.`Customer`.`CustNo`                         AS `CustNo`,
                `win_main`.`Customer`.`AssignedRepID`                  AS `AssignedRepID`,
                `win_main`.`Member`.`ADMNumber`                        AS `AdmNo`,
                `win_main`.`Product`.`Ean`                             AS `Ean`
from ((((`win_main`.`DW_PurchaseHistories` left join `win_main`.`Product_Dimension` on ((
        `win_main`.`DW_PurchaseHistories`.`ProductNumber` =
        `win_main`.`Product_Dimension`.`ArtNo`))) left join `win_main`.`Customer` on ((
        `win_main`.`DW_PurchaseHistories`.`CustomerID` =
        `win_main`.`Customer`.`ID`))) left join `win_main`.`Member` on ((`win_main`.`Customer`.`AssignedRepID` = `win_main`.`Member`.`ID`)))
         left join `win_main`.`Product`
                   on ((`win_main`.`DW_PurchaseHistories`.`ProductNumber` = `win_main`.`Product`.`ArtNo`)))
where (`win_main`.`DW_PurchaseHistories`.`InvoiceNumber` = '4155609329')
order by `win_main`.`DW_PurchaseHistories`.`ProductNumber` desc;

