create definer = root@`%` view Cust_Hist as
select `win_main`.`DW_PurchaseHistories`.`CustomerID`         AS `CustomerID`,
       `win_main`.`DW_PurchaseHistories`.`ProductNumber`      AS `ProductNumber`,
       `win_main`.`DW_PurchaseHistories`.`ProductDescription` AS `ProductDescription`,
       `win_main`.`DW_PurchaseHistories`.`Amount`             AS `Turnover`,
       min(`win_main`.`DW_PurchaseHistories`.`InvoiceDate`)   AS `FirstPurchase`,
       max(`win_main`.`DW_PurchaseHistories`.`InvoiceDate`)   AS `LastPurchase`
from `win_main`.`DW_PurchaseHistories`
where (year(`win_main`.`DW_PurchaseHistories`.`InvoiceDate`) > '2016')
group by `win_main`.`DW_PurchaseHistories`.`CustomerID`, `win_main`.`DW_PurchaseHistories`.`ProductNumber`;

