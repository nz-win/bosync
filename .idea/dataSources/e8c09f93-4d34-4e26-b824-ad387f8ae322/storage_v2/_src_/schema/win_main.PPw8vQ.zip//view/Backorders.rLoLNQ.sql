create definer = root@`%` view Backorders as
(
select `bo`.`business_area_no`               AS `business_area_no`,
       `bo`.`area_no`                        AS `sales_area_no`,
       `bo`.`adm_no`                         AS `adm_no`,
       coalesce(`m`.`FullName`, '?')         AS `rep_name`,
       `bo`.`order_no`                       AS `order_no`,
       `bo`.`customer_no`                    AS `sold_to_customer_no`,
       coalesce(`c`.`Name`, '?')             AS `customer_name`,
       `bo`.`material_no`                    AS `material_no`,
       `bo`.`sale_date`                      AS `sale_date`,
       `bo`.`material_eta_date`              AS `material_eta_date`,
       `bo`.`backorder_qty`                  AS `backorder_qty`,
       replace(`bo`.`material_no`, ' ', '#') AS `normalized_material_no`,
       substr(`bo`.`material_no`, 1, 10)     AS `article`,
       substr(`bo`.`material_no`, 10, 3)     AS `presentation`,
       substr(`bo`.`material_no`, 13, 5)     AS `pack_size`,
       coalesce(`p`.`Name`, '?')             AS `product_descr`
from (((`win_main`.`ActiveBackorders` `bo` left join `win_main`.`Member` `m` on ((`m`.`ADMNumber` = `bo`.`adm_no`))) left join `win_main`.`Customer` `c` on ((`c`.`CustNo` = convert(`bo`.`customer_no` using utf8))))
         left join `win_main`.`Product` `p`
                   on ((`p`.`ArtNo` = convert(substr(`bo`.`material_no`, 1, 10) using utf8)))));

