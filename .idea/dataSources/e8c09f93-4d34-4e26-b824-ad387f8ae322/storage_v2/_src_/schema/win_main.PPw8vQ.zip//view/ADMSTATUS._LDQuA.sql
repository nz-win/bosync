create definer = root@`%` view ADMSTATUS as
select `win_main`.`Member`.`ADMNumber` AS `AdmNo`,
       `win_main`.`Member`.`FullName`  AS `Name`,
       `win_main`.`Division`.`Name`    AS `Division`,
       `win_main`.`Team`.`TeamNo`      AS `TeamNo`,
       `win_main`.`Member`.`StartDate` AS `StartDate`,
       `win_main`.`Member`.`ExitDate`  AS `ExitDate`
from (((`win_main`.`Member` left join `win_main`.`Rep` on ((`win_main`.`Rep`.`MemberID` = `win_main`.`Member`.`ID`))) left join `win_main`.`Team` on ((`win_main`.`Rep`.`TeamID` = `win_main`.`Team`.`ID`)))
         left join `win_main`.`Division` on ((`win_main`.`Team`.`DivisionID` = `win_main`.`Division`.`ID`)))
where (`win_main`.`Member`.`ADMNumber` <> 0);

