create definer = root@`%` view OrsyLabels as
select `win_main`.`DW_PurchaseHistories`.`ProductNumber`      AS `ArtNo`,
       `win_main`.`DW_PurchaseHistories`.`ProductDescription` AS `Art_Description`,
       `win_main`.`Product_Dimension`.`Diameter`              AS `Diameter`,
       `win_main`.`Product_Dimension`.`Lenth`                 AS `Lenth`,
       `win_main`.`Product_Dimension`.`ImageMap`              AS `ImageMap`,
       `win_main`.`Customer`.`Name`                           AS `Name`,
       `win_main`.`Customer`.`CustNo`                         AS `CustNo`,
       `win_main`.`Customer`.`AssignedRepID`                  AS `AssignedRepID`,
       `win_main`.`Member`.`ADMNumber`                        AS `AdmNo`
from (((`win_main`.`DW_PurchaseHistories` left join `win_main`.`Product_Dimension` on ((
        `win_main`.`DW_PurchaseHistories`.`ProductNumber` =
        `win_main`.`Product_Dimension`.`ArtNo`))) left join `win_main`.`Customer` on ((
        `win_main`.`DW_PurchaseHistories`.`CustomerID` = `win_main`.`Customer`.`ID`)))
         left join `win_main`.`Member` on ((`win_main`.`Customer`.`AssignedRepID` = `win_main`.`Member`.`ID`)))
where (not ((`win_main`.`DW_PurchaseHistories`.`ProductNumber` like '00000 000%')));

