create definer = root@`%` view RepToCurMonth as
select cast(`win_main`.`DW_SalesStatistics`.`ADMNumber` as unsigned) AS `ADMNumber`,
       `win_main`.`DW_SalesStatistics`.`Month`                       AS `Month`,
       `win_main`.`DW_SalesStatistics`.`Year`                        AS `Year`,
       sum(`win_main`.`DW_SalesStatistics`.`DailyTurnover`)          AS `Tunrover`
from `win_main`.`DW_SalesStatistics`
where ((`win_main`.`DW_SalesStatistics`.`Month` = if((month(curdate()) = 1), 12, (month(curdate()) - 1))) and
       (`win_main`.`DW_SalesStatistics`.`Year` = if((month(curdate()) = 1), (year(curdate()) - 1), year(curdate()))))
group by `win_main`.`DW_SalesStatistics`.`ADMNumber`;

