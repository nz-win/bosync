create definer = root@`%` view agpl as
select `win_main`.`DW_PurchaseHistories`.`Amount`                               AS `Amount`,
       `win_main`.`DW_PurchaseHistories`.`InvoiceDate`                          AS `InvoiceDate`,
       `win_main`.`DW_PurchaseHistories`.`ProductNumber`                        AS `ProductNumber`,
       `win_main`.`DW_PurchaseHistories`.`Quantity`                             AS `Quantity`,
       `win_main`.`DW_PurchaseHistories`.`ProductDescription`                   AS `ProductDescription`,
       `win_main`.`DW_PurchaseHistories`.`InvoiceNumber`                        AS `InvoiceNumber`,
       `win_main`.`DW_PurchaseHistories`.`CustomerID`                           AS `CustomerID`,
       `win_main`.`DW_PurchaseHistories`.`CustomerReference`                    AS `CustomerReference`,
       `win_main`.`Customer`.`CustNo`                                           AS `CustNo`,
       `win_main`.`Customer`.`Name`                                             AS `Name`,
       cast(month(`win_main`.`DW_PurchaseHistories`.`InvoiceDate`) as unsigned) AS `Month`,
       cast(year(`win_main`.`DW_PurchaseHistories`.`InvoiceDate`) as unsigned)  AS `Year`,
       substr(`win_main`.`DW_PurchaseHistories`.`ProductNumber`, 1, 4)          AS `Prefix`,
       `win_main`.`Product_Group`.`Group`                                       AS `Group`
from ((`win_main`.`DW_PurchaseHistories` left join `win_main`.`Customer` on ((
        `win_main`.`DW_PurchaseHistories`.`CustomerID` = `win_main`.`Customer`.`ID`)))
         left join `win_main`.`Product_Group` on ((substr(`win_main`.`DW_PurchaseHistories`.`ProductNumber`, 1, 4) =
                                                   `win_main`.`Product_Group`.`Prefix`)))
where (`win_main`.`Customer`.`CustNo` in (120130511, 120129904, 120130511));

