create definer = root@`%` view Find_Customer_Transfer as
select `win_main`.`Customer`.`CustNo`                               AS `CustNo`,
       `win_main`.`Customer`.`Name`                                 AS `Name`,
       `win_main`.`Customer`.`ID`                                   AS `ID`,
       `win_main`.`CustomerTransfer_Customers`.`CustomerTransferID` AS `CustomerTransferID`,
       `win_main`.`CustomerTransfer`.`ID`                           AS `CTID`,
       `win_main`.`CustomerTransfer`.`Approved`                     AS `Approved`
from ((`win_main`.`Customer` left join `win_main`.`CustomerTransfer_Customers` on ((`win_main`.`Customer`.`ID` =
                                                                                    `win_main`.`CustomerTransfer_Customers`.`CustomerID`)))
         left join `win_main`.`CustomerTransfer` on ((`win_main`.`CustomerTransfer_Customers`.`CustomerTransferID` =
                                                      `win_main`.`CustomerTransfer`.`ID`)))
where (`win_main`.`Customer`.`CustNo` = 120137564);

