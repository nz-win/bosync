create definer = root@`%` view MarynasResultsLastYear as
select cast(`win_main`.`DW_SalesStatistics`.`ADMNumber` as unsigned)        AS `ADMNumber`,
       cast(`win_main`.`DW_SalesStatistics`.`Year` as char charset utf8mb4) AS `Year`,
       `win_main`.`DW_SalesStatistics`.`Year`                               AS `YearNo`,
       sum(`win_main`.`DW_SalesStatistics`.`DailyTurnover`)                 AS `Tunrover`
from `win_main`.`DW_SalesStatistics`
where ((`win_main`.`DW_SalesStatistics`.`Year` = (year(curdate()) - 1)) and
       (`win_main`.`DW_SalesStatistics`.`Month` <= (month(curdate()) - 1)))
group by `win_main`.`DW_SalesStatistics`.`ADMNumber`;

