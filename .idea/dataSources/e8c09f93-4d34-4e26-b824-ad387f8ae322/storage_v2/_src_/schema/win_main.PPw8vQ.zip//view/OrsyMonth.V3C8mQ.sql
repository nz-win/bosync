create definer = root@`%` view OrsyMonth as
select `win_main`.`Customer`.`CustNo`                  AS `CustNo`,
       `win_main`.`Customer`.`Name`                    AS `Name`,
       `win_main`.`Customer`.`Orsy`                    AS `Orsy`,
       `win_main`.`Customer`.`ID`                      AS `ID`,
       `win_main`.`Customer`.`PreviousRollingTurnover` AS `PreviousRollingTurnover`,
       `win_main`.`Customer`.`CurrentRollingTurnover`  AS `CurrentRollingTurnover`,
       `win_main`.`Member`.`ADMNumber`                 AS `ADMNumber`,
       `win_main`.`Member`.`FullName`                  AS `FullName`,
       `win_main`.`Team`.`Name`                        AS `Team`,
       `win_main`.`Division`.`Name`                    AS `Division`
from ((((`win_main`.`Customer` left join `win_main`.`Member` on ((`win_main`.`Customer`.`AssignedRepID` = `win_main`.`Member`.`ID`))) left join `win_main`.`Rep` on ((`win_main`.`Rep`.`MemberID` = `win_main`.`Member`.`ID`))) left join `win_main`.`Team` on ((`win_main`.`Team`.`ID` = `win_main`.`Rep`.`TeamID`)))
         left join `win_main`.`Division` on ((`win_main`.`Division`.`ID` = `win_main`.`Team`.`DivisionID`)))
where (`win_main`.`Customer`.`Orsy` = 1)
group by `win_main`.`Customer`.`CustNo`;

