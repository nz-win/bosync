create definer = root@`%` view DivisionProductFocus as
select `win_main`.`DW_PurchaseHistories`.`InvoiceDate`        AS `InvoiceDate`,
       `win_main`.`DW_PurchaseHistories`.`ProductNumber`      AS `ProductNumber`,
       `win_main`.`DW_PurchaseHistories`.`Quantity`           AS `Quantity`,
       `win_main`.`DW_PurchaseHistories`.`PriceUnit`          AS `PriceUnit`,
       `win_main`.`DW_PurchaseHistories`.`ProductDescription` AS `ProductDescription`,
       `win_main`.`DW_PurchaseHistories`.`UnitPrice`          AS `UnitPrice`,
       `win_main`.`Member`.`ADMNumber`                        AS `ADMNumber`,
       `win_main`.`Member`.`FullName`                         AS `FullName`,
       `win_main`.`DW_PurchaseHistories`.`Amount`             AS `Amount`,
       `win_main`.`Team`.`Name`                               AS `Name`
from (((`win_main`.`DW_PurchaseHistories` left join `win_main`.`Member` on ((
        `win_main`.`DW_PurchaseHistories`.`MemberID` =
        `win_main`.`Member`.`ID`))) left join `win_main`.`Rep` on ((`win_main`.`Member`.`ID` = `win_main`.`Rep`.`MemberID`)))
         left join `win_main`.`Team` on ((`win_main`.`Rep`.`TeamID` = `win_main`.`Team`.`ID`)))
where ((`win_main`.`DW_PurchaseHistories`.`ProductNumber` = 827940114) and
       (`win_main`.`DW_PurchaseHistories`.`InvoiceDate` >= '2020-12-01'));

