create definer = root@`%` view CurrMonthCustTO as
select `win_main`.`DW_PurchaseHistories`.`CustomerID`  AS `CustomerID`,
       sum(`win_main`.`DW_PurchaseHistories`.`Amount`) AS `MonthTO`
from `win_main`.`DW_PurchaseHistories`
where ((month(`win_main`.`DW_PurchaseHistories`.`InvoiceDate`) =
        if((month(curdate()) = 1), 1, (month(curdate()) - 1))) and
       (year(`win_main`.`DW_PurchaseHistories`.`InvoiceDate`) =
        if((month(curdate()) = 1), (year(curdate()) - 1), year(curdate()))))
group by `win_main`.`DW_PurchaseHistories`.`CustomerID`;

